# Push this to GitHub

The repo is already committed locally. Pick ONE of the options below.

## Option A — GitHub CLI (fastest)
Requires the `gh` CLI installed and logged in (`gh auth login`).

```bash
cd getkong-webflow-custom-code
gh repo create getkong-webflow-custom-code --private --source=. --push
```

Add Fabian as a collaborator:
```bash
gh repo add-collaborator <org-or-you>/getkong-webflow-custom-code <fabian-github-username>
```

## Option B — create the repo in the browser, then push
1. Create a new **empty** private repo on GitHub (no README/.gitignore).
2. Then, from the folder:

```bash
cd getkong-webflow-custom-code
git init            # only if not already a git repo
git add -A
git commit -m "GETKONG Webflow custom code"
git branch -M main
git remote add origin git@github.com:<owner>/getkong-webflow-custom-code.git
git push -u origin main
```

(Use the `https://github.com/...` URL instead of `git@...` if you don't use SSH.)

## Option C — no git at all
Open the new empty repo on GitHub → "uploading an existing file" → drag in the
contents of this folder (or the zip's contents). Fine for a one‑off handover.
